import React from 'react';
import {
  EquipmentPairPageData,
  SingleEquipmentMonthData,
} from '../utils/inspectionAggregation';
import {
  FORM_METADATA,
  HARNESS_CHECKLIST_ITEMS,
  LANYARD_CHECKLIST_ITEMS,
} from '../constants/masterTemplates';
import { generateDigitalSignaturePng } from '../utils/signatureUtils';

interface SingleEquipmentReportTemplateProps {
  pageData: EquipmentPairPageData;
  idPrefix?: string;
  onDaySignatureClick?: (equipmentType: 'harness' | 'lanyard', day: number, inspectorName?: string) => void;
}

/**
 * 100% Canvas & PDF-safe Vector Checkmark component
 */
const CheckmarkSvg: React.FC<{ size?: number; className?: string }> = ({ size = 14, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`inline-block shrink-0 ${className}`}
    style={{ display: 'inline-block', verticalAlign: 'middle' }}
  >
    <polyline
      points="2 6.2 4.8 9.2 10 2.8"
      stroke="#000000"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

/**
 * 100% Canvas & PDF-safe Vector Cross component
 */
const CrossSvg: React.FC<{ size?: number; className?: string }> = ({ size = 13, className = '' }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={`inline-block shrink-0 ${className}`}
    style={{ display: 'inline-block', verticalAlign: 'middle' }}
  >
    <line x1="2.5" y1="2.5" x2="9.5" y2="9.5" stroke="#000000" strokeWidth="2.2" strokeLinecap="round" />
    <line x1="9.5" y1="2.5" x2="2.5" y2="9.5" stroke="#000000" strokeWidth="2.2" strokeLinecap="round" />
  </svg>
);

/**
 * Formats checklist items with exact line breaks, spacing, and phrasing
 * matching the Microsoft Word 2019 master report template identically.
 */
const renderChecklistItemText = (equipmentType: 'harness' | 'lanyard', itemId: number) => {
  if (equipmentType === 'harness') {
    switch (itemId) {
      case 1:
        return (
          <>
            D-ring และหัวเข็มขัดต้องอยู่ในสภาพดี ไม่บิดเบี้ยว<br />
            ไม่มีรอยแตกร้าว สนิม และขอบคม<br />
            หัวเข็มขัดต้องปรับเลื่อนได้โดยไม่ติดขัด
          </>
        );
      case 2:
        return (
          <>
            สายรัดต้องอยู่ในสภาพดี ไม่มีรอยตัด ฉีกขาด รอยไหม้<br />
            เส้นด้ายหลุดลุ่ย หรือสีซีดจาง
          </>
        );
      case 3:
        return <>รอยเย็บต้องแน่นและไม่มีรอยตัด</>;
      case 4:
        return <>ป้ายเครื่องหมายต้องอยู่ในสภาพดี ไม่ขาด ตัวหนังสือชัดเจน</>;
      default:
        return null;
    }
  } else {
    switch (itemId) {
      case 1:
        return (
          <>
            ตะขอเกี่ยว, Carabiner และ D-ring ต้องอยู่ในสภาพดี<br />
            ไม่บิดเบี้ยว ไม่มีรอยแตกร้าว สนิม และขอบคม
          </>
        );
      case 2:
        return (
          <>
            สายรัด Lanyard ต้องอยู่ในสภาพดี ไม่มีรอยตัด ฉีกขาด<br />
            รอยไหม้ เส้นด้ายหลุดลุ่ย หรือสีซีดจาง
          </>
        );
      case 3:
        return <>รอยเย็บ Lanyard ต้องแน่น และไม่มีรอยตัด</>;
      case 4:
        return (
          <>
            เชือก Lanyard ต้องอยู่ในสภาพดี แน่นเป็นเส้นเดียวกัน<br />
            ไม่มีรอยตัด รอยไหม้ ไม่พันกันเป็นปม หรือสีซีดจาง
          </>
        );
      case 5:
        return (
          <>
            อุปกรณ์ดูดซับแรงกระชาก ต้องอยู่ในสภาพดี ไม่ยืดออก<br />
            และไม่ฉีกขาด
          </>
        );
      case 6:
        return (
          <>
            ป้ายเครื่องหมาย ต้องอยู่ในสภาพดี ไม่ขาด<br />
            ตัวหนังสือชัดเจน
          </>
        );
      default:
        return null;
    }
  }
};

/**
 * Sub-component for rendering a single equipment's header box and 31-day checklist table
 * Built as an EXACT 1:1 digital twin of the Microsoft Word template (FM-004/QP-PB-013)
 * Full 13.5pt (18px) TH Sarabun New font for maximum clarity and exact document fidelity
 */
const EquipmentSection: React.FC<{
  data: SingleEquipmentMonthData;
  month: string;
  year: string;
  onDaySignatureClick?: (equipmentType: 'harness' | 'lanyard', day: number, inspectorName?: string) => void;
}> = ({ data, month, year, onDaySignatureClick }) => {
  const isHarness = data.equipmentType === 'harness';
  const checklistItems = isHarness ? HARNESS_CHECKLIST_ITEMS : LANYARD_CHECKLIST_ITEMS;
  const days = Array.from({ length: 31 }, (_, i) => i + 1);

  const eq = data.equipment;
  const hasData = !!eq.name;
  const cleanName = (eq.name || '').replace(/[✓√✔]/g, '').trim();
  const isChecked = data.isCheckedInMonth || eq.isCheckedInReport;

  return (
    <div style={{ width: '1078px', boxSizing: 'border-box' }}>
      {/* 1. Single-line Equipment Info Table */}
      <table
        style={{
          width: '1078px',
          tableLayout: 'fixed',
          borderCollapse: 'collapse',
          border: '1px solid #000000',
          marginBottom: '3px',
          backgroundColor: '#ffffff',
          color: '#000000',
          fontFamily: "'TH Sarabun New', 'THSarabunNew', 'TH Sarabun PSK', 'Sarabun', Tahoma, sans-serif",
        }}
      >
        <colgroup>
          <col style={{ width: '270px' }} />
          <col style={{ width: '218px' }} />
          <col style={{ width: '228px' }} />
          <col style={{ width: '362px' }} />
        </colgroup>
        <tbody>
          <tr style={{ height: '22px' }}>
            {/* Col 1: ชื่อเครื่องมืออุปกรณ์ */}
            <td
              style={{
                border: '1px solid #000000',
                padding: '1px 6px',
                verticalAlign: 'middle',
                textAlign: 'left',
                fontSize: '16px',
                fontWeight: 'normal',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                lineHeight: 1.25,
              }}
            >
              <span>ชื่อเครื่องมืออุปกรณ์:&nbsp;</span>
              {hasData ? (
                <span>{cleanName}</span>
              ) : (
                <span>-</span>
              )}
            </td>

            {/* Col 2: รหัสประจำตัวอุปกรณ์ */}
            <td
              style={{
                border: '1px solid #000000',
                padding: '1px 6px',
                verticalAlign: 'middle',
                textAlign: 'left',
                fontSize: '16px',
                fontWeight: 'normal',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                lineHeight: 1.25,
              }}
            >
              <span>รหัสประจำตัวอุปกรณ์:&nbsp;</span>
              <span>{hasData ? eq.sn || '-' : '-'}</span>
            </td>

            {/* Col 3: ทะเบียน กฟผ. */}
            <td
              style={{
                border: '1px solid #000000',
                padding: '1px 6px',
                verticalAlign: 'middle',
                textAlign: 'left',
                fontSize: '16px',
                fontWeight: 'normal',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                lineHeight: 1.25,
              }}
            >
              <span>ทะเบียน กฟผ.:&nbsp;</span>
              <span>{hasData ? eq.egatNo || '-' : '-'}</span>
            </td>

            {/* Col 4: ยี่ห้อ/รุ่น */}
            <td
              style={{
                border: '1px solid #000000',
                padding: '1px 6px',
                verticalAlign: 'middle',
                textAlign: 'left',
                fontSize: '16px',
                fontWeight: 'normal',
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                lineHeight: 1.25,
              }}
            >
              <span>ยี่ห้อ/รุ่น:&nbsp;</span>
              <span>{hasData ? eq.brandModel || '-' : '-'}</span>
            </td>
          </tr>
        </tbody>
      </table>

      {/* 2. Checklist Table (Days 1..31) */}
      <table
        style={{
          width: '1078px',
          tableLayout: 'fixed',
          borderCollapse: 'collapse',
          border: '1px solid #000000',
          backgroundColor: '#ffffff',
          color: '#000000',
          boxSizing: 'border-box',
          fontFamily: "'TH Sarabun New', 'THSarabunNew', 'TH Sarabun PSK', 'Sarabun', Tahoma, sans-serif",
        }}
      >
        <colgroup>
          <col style={{ width: '35px' }} />
          <col style={{ width: '295px' }} />
          {days.map((d) => (
            <col key={d} style={{ width: '21.77px' }} />
          ))}
          <col style={{ width: '73px' }} />
        </colgroup>

        <thead>
          {/* Header Row 1 */}
          <tr style={{ height: '24px' }}>
            <th
              rowSpan={2}
              style={{
                width: '35px',
                border: '1px solid #000000',
                textAlign: 'center',
                verticalAlign: 'middle',
                fontSize: '16px',
                fontWeight: 'normal',
                padding: '2px 3px',
                lineHeight: 1.15,
                backgroundColor: '#ffffff',
              }}
            >
              ลำดับ<br />ที่
            </th>
            <th
              rowSpan={2}
              style={{
                width: '295px',
                border: '1px solid #000000',
                textAlign: 'center',
                verticalAlign: 'middle',
                fontSize: '16px',
                fontWeight: 'normal',
                padding: '2px 10px',
                lineHeight: 1.15,
                backgroundColor: '#ffffff',
              }}
            >
              รายการตรวจสอบ
            </th>
            <th
              colSpan={31}
              style={{
                width: '675px',
                border: '1px solid #000000',
                textAlign: 'center',
                verticalAlign: 'middle',
                fontSize: '16px',
                fontWeight: 'normal',
                padding: '2px 4px',
                lineHeight: 1.15,
                backgroundColor: '#ffffff',
              }}
            >
              เดือน {month || '............'} พ.ศ. {year || '........'}
            </th>
            <th
              rowSpan={2}
              style={{
                width: '73px',
                border: '1px solid #000000',
                textAlign: 'center',
                verticalAlign: 'middle',
                fontSize: '16px',
                fontWeight: 'normal',
                padding: '2px 3px',
                lineHeight: 1.15,
                backgroundColor: '#ffffff',
              }}
            >
              หมายเหตุ
            </th>
          </tr>

          {/* Header Row 2: Days 1 to 31 */}
          <tr style={{ height: '19px' }}>
            {days.map((d) => (
              <th
                key={d}
                style={{
                  width: '21.77px',
                  height: '19px',
                  border: '1px solid #000000',
                  textAlign: 'center',
                  verticalAlign: 'middle',
                  fontSize: '13.5px',
                  fontWeight: 'normal',
                  padding: 0,
                  backgroundColor: '#ffffff',
                  lineHeight: 1,
                }}
              >
                {d}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {/* Checklist Item Rows */}
          {checklistItems.map((item) => (
            <tr key={item.id} style={{ height: isHarness ? '24px' : '22px' }}>
              {/* ลำดับที่ */}
              <td
                style={{
                  width: '35px',
                  height: isHarness ? '24px' : '22px',
                  border: '1px solid #000000',
                  textAlign: 'center',
                  verticalAlign: 'middle',
                  fontSize: '16px',
                  fontWeight: 'normal',
                  padding: '2px 3px',
                }}
              >
                {item.id}
              </td>

              {/* รายการตรวจสอบ */}
              <td
                style={{
                  width: '295px',
                  height: isHarness ? '24px' : '22px',
                  border: '1px solid #000000',
                  textAlign: 'left',
                  verticalAlign: 'middle',
                  fontSize: '15.5px',
                  lineHeight: '1.24',
                  padding: '3px 8px',
                  fontWeight: 'normal',
                }}
              >
                {renderChecklistItemText(data.equipmentType, item.id) || item.text}
              </td>

              {/* 31 Day Check Cells (shows '/' like in Word) */}
              {days.map((d) => {
                const res = data.dayResults[d]?.[item.id];
                const isInspectedDay = data.inspectedDays.includes(d);
                const rawSymbol = isInspectedDay ? (res || '✓') : '';
                // Any normal inspection result ('/', '√', '✓') matches the example [✓] in the legend
                const symbol = (rawSymbol === '/' || rawSymbol === '√') ? '✓' : rawSymbol;

                return (
                  <td
                    key={d}
                    style={{
                      width: '21.77px',
                      height: isHarness ? '24px' : '22px',
                      border: '1px solid #000000',
                      textAlign: 'center',
                      verticalAlign: 'middle',
                      padding: 0,
                    }}
                  >
                    {symbol === '✓' && (
                      <span
                        style={{
                          fontSize: '16px',
                          fontWeight: 'normal',
                          lineHeight: '1',
                          display: 'inline-block',
                          verticalAlign: 'middle',
                        }}
                      >
                        ✓
                      </span>
                    )}
                    {(symbol === 'X' || symbol === '✕') && (
                      <span
                        style={{
                          fontSize: '15px',
                          fontWeight: 'normal',
                          lineHeight: '1',
                          display: 'inline-block',
                          verticalAlign: 'middle',
                        }}
                      >
                        ✕
                      </span>
                    )}
                    {symbol === '■' && (
                      <span
                        style={{
                          fontSize: '14px',
                          lineHeight: '1',
                          display: 'inline-block',
                          verticalAlign: 'middle',
                        }}
                      >
                        ■
                      </span>
                    )}
                    {symbol && !['✓', 'X', '✕', '■'].includes(symbol) && (
                      <span
                        style={{
                          fontSize: '13.5px',
                          fontWeight: 'normal',
                          lineHeight: '1',
                          display: 'inline-block',
                          verticalAlign: 'middle',
                        }}
                      >
                        {symbol}
                      </span>
                    )}
                  </td>
                );
              })}

              {/* หมายเหตุ */}
              <td
                style={{
                  width: '73px',
                  height: isHarness ? '24px' : '22px',
                  border: '1px solid #000000',
                  textAlign: 'center',
                  verticalAlign: 'middle',
                  padding: '1px',
                }}
              ></td>
            </tr>
          ))}

          {/* Bottom Row: Status Legend + ลงชื่อ ผู้ตรวจสอบ (Per-Day Signatures) */}
          <tr style={{ height: '40px' }}>
            {/* Left: Legend & Label (spans columns 1 and 2) */}
            <td
              colSpan={2}
              style={{
                width: '330px',
                maxWidth: '330px',
                height: '40px',
                border: '1px solid #000000',
                verticalAlign: 'middle',
                padding: '3px 10px',
                overflow: 'hidden',
                boxSizing: 'border-box',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  width: '100%',
                  height: '100%',
                  gap: '2px',
                  overflow: 'hidden',
                }}
              >
                {/* Row 1: Status Legend */}
                <div
                  style={{
                    textAlign: 'left',
                    fontSize: '13.5px',
                    color: '#000000',
                    lineHeight: 1.2,
                    whiteSpace: 'nowrap',
                    width: '100%',
                    paddingLeft: '2px',
                  }}
                >
                  <span>[✓] ปกติ&nbsp;&nbsp;&nbsp;[✕] ผิดปกติ ใช้ได้&nbsp;&nbsp;&nbsp;[■] ห้ามใช้</span>
                </div>

                {/* Row 2: ลงชื่อ ผู้ตรวจสอบ */}
                <div
                  style={{
                    textAlign: 'right',
                    fontSize: '15px',
                    color: '#000000',
                    lineHeight: 1.2,
                    whiteSpace: 'nowrap',
                    width: '100%',
                    paddingRight: '4px',
                  }}
                >
                  <span style={{ fontWeight: 'normal' }}>ลงชื่อ ผู้ตรวจสอบ</span>
                </div>
              </div>
            </td>

            {/* 31 Individual Day Signature Cells */}
            {days.map((d) => {
              const isInspected = data.inspectedDays.includes(d);
              const dayInsp = data.dayInspectors[d];
              let signatureSrc = dayInsp?.verticalSignatureDataUrl;
              if (isInspected && (!signatureSrc || !signatureSrc.startsWith('data:image/'))) {
                const gen = generateDigitalSignaturePng(dayInsp?.inspectorName || 'ผู้ตรวจสอบ');
                signatureSrc = gen.vertical;
              }

              return (
                <td
                  key={d}
                  onClick={() => {
                    if (onDaySignatureClick && isInspected) {
                      onDaySignatureClick(data.equipmentType, d, dayInsp?.inspectorName);
                    }
                  }}
                  title={isInspected ? `ผู้ตรวจวันที่ ${d}: ${dayInsp?.inspectorName || 'ผู้ตรวจสอบ'}` : undefined}
                  style={{
                    width: '21.77px',
                    height: '40px',
                    border: '1px solid #000000',
                    textAlign: 'center',
                    verticalAlign: 'middle',
                    padding: 0,
                    cursor: isInspected ? 'pointer' : 'default',
                    backgroundColor: '#ffffff',
                    overflow: 'hidden',
                  }}
                >
                  {isInspected && (
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        width: '100%',
                        height: '100%',
                        overflow: 'hidden',
                      }}
                    >
                      {signatureSrc ? (
                        <img
                          src={signatureSrc}
                          alt={dayInsp?.inspectorName || 'ลายเซ็น'}
                          loading="eager"
                          decoding="sync"
                          referrerPolicy="no-referrer"
                          style={{
                            maxWidth: '16px',
                            maxHeight: '32px',
                            width: 'auto',
                            height: 'auto',
                            objectFit: 'contain',
                            display: 'block',
                            margin: 'auto',
                            backgroundColor: 'transparent',
                          }}
                        />
                      ) : (
                        <span
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            width: '12px',
                            height: '12px',
                            border: '1px solid #000000',
                            backgroundColor: '#ffffff',
                          }}
                        >
                          <CheckmarkSvg size={9} />
                        </span>
                      )}
                    </div>
                  )}
                </td>
              );
            })}

            {/* Right Box: ผู้รายงาน */}
            <td
              style={{
                width: '73px',
                height: '40px',
                border: '1px solid #000000',
                textAlign: 'center',
                verticalAlign: 'middle',
                padding: '1px 3px',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  width: '100%',
                  height: '100%',
                  gap: '1px',
                }}
              >
                {(() => {
                  let reporterSig = data.primaryInspector?.signatureDataUrl;
                  if (!reporterSig || !reporterSig.startsWith('data:image/')) {
                    reporterSig = generateDigitalSignaturePng(data.primaryInspector?.name || 'ผู้รายงาน').horizontal;
                  }
                  return reporterSig ? (
                    <img
                      src={reporterSig}
                      alt={data.primaryInspector?.name || 'ผู้รายงาน'}
                      loading="eager"
                      decoding="sync"
                      referrerPolicy="no-referrer"
                      style={{
                        maxHeight: '22px',
                        maxWidth: '69px',
                        width: 'auto',
                        height: 'auto',
                        objectFit: 'contain',
                        display: 'block',
                        margin: 'auto',
                        backgroundColor: 'transparent',
                      }}
                    />
                  ) : null;
                })()}
                <span
                  style={{
                    fontSize: '15px',
                    fontWeight: 'normal',
                    lineHeight: '1',
                    whiteSpace: 'nowrap',
                    color: '#000000',
                    textAlign: 'center',
                  }}
                >
                  ผู้รายงาน
                </span>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export const SingleEquipmentReportTemplate: React.FC<SingleEquipmentReportTemplateProps> = ({
  pageData,
  idPrefix = 'single-report-page',
  onDaySignatureClick,
}) => {
  const pageId = `${idPrefix}-set-${pageData.pairNumber}`;

  return (
    <div
      id={pageId}
      className="bg-white text-black select-none shadow-md print:shadow-none mx-auto"
      style={{
        width: '1122px',
        height: '793px',
        minHeight: '793px',
        maxHeight: '793px',
        padding: '10px 22px 8px 22px',
        boxSizing: 'border-box',
        fontFamily: "'TH Sarabun New', 'THSarabunNew', 'TH Sarabun PSK', 'Sarabun', Tahoma, sans-serif",
        color: '#000000',
        backgroundColor: '#ffffff',
        overflow: 'hidden',
        lineHeight: 1.2,
      }}
    >
      {/* 1. Header Title */}
      <div style={{ textAlign: 'center', marginBottom: '2px' }}>
        <h1
          style={{
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#000000',
            margin: 0,
            padding: 0,
            lineHeight: 1.15,
          }}
        >
          {FORM_METADATA.title}
        </h1>
      </div>

      {/* 2. Subheader Metadata */}
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-start',
          fontSize: '15px',
          fontWeight: 'bold',
          color: '#000000',
          padding: '0 2px',
          marginBottom: '3px',
          gap: '32px',
          lineHeight: 1.15,
        }}
      >
        <span>เรียน&nbsp;&nbsp;หมผ - ธ.</span>
        <span>แผนก&nbsp;&nbsp;หมผ - ธ.</span>
        <span>กอง&nbsp;&nbsp;กคว - ธ.</span>
        <span>ฝ่าย&nbsp;&nbsp;อคม.&nbsp;&nbsp;รวธ.</span>
      </div>

      {/* 3. Section 1: Full Body Harness */}
      <EquipmentSection
        data={pageData.harnessData}
        month={pageData.month}
        year={pageData.year}
        onDaySignatureClick={onDaySignatureClick}
      />

      {/* Clean vertical separator between Harness & Lanyard */}
      <div style={{ height: '6px' }} />

      {/* 4. Section 2: Lanyard */}
      <EquipmentSection
        data={pageData.lanyardData}
        month={pageData.month}
        year={pageData.year}
        onDaySignatureClick={onDaySignatureClick}
      />

      {/* 5. Footer: Copy Note & Document Revision Bar */}
      <div
        style={{
          fontSize: '15px',
          color: '#000000',
          margin: '3px 0 2px 2px',
          lineHeight: 1.15,
        }}
      >
        {FORM_METADATA.copyNote}
      </div>

      {/* Revision Table matching Word's 3-column bordered table */}
      <table
        style={{
          width: '1078px',
          tableLayout: 'fixed',
          borderCollapse: 'collapse',
          border: '1px solid #000000',
          backgroundColor: '#ffffff',
          color: '#000000',
          textAlign: 'center',
          fontSize: '15px',
          fontFamily: "'TH Sarabun New', 'THSarabunNew', 'TH Sarabun PSK', 'Sarabun', Tahoma, sans-serif",
          lineHeight: 1.25,
        }}
      >
        <tbody>
          <tr style={{ height: '28px' }}>
            <td
              style={{
                width: '33.33%',
                border: '1px solid #000000',
                padding: '2px 6px',
                verticalAlign: 'middle',
                textAlign: 'center',
                fontWeight: 'normal',
              }}
            >
              {FORM_METADATA.subdivision}
            </td>
            <td
              style={{
                width: '33.33%',
                border: '1px solid #000000',
                padding: '2px 6px',
                verticalAlign: 'middle',
                textAlign: 'center',
                fontWeight: 'normal',
              }}
            >
              {FORM_METADATA.docNumber}
            </td>
            <td
              style={{
                width: '33.34%',
                border: '1px solid #000000',
                padding: '2px 6px',
                verticalAlign: 'middle',
                textAlign: 'center',
                fontWeight: 'normal',
              }}
            >
              {FORM_METADATA.revision}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};
