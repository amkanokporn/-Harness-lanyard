/**
 * Thai Name Normalization, Grammatical Spelling Correction & Fuzzy Deduplication Module
 *
 * Implements:
 * 1. Rule-based Thai grammatical correction (fixing missing karun/thantakhat, incomplete vowels, common typos)
 * 2. Canonical roster dictionary for EGAT Power Plant safety inspectors
 * 3. Levenshtein string distance and Thai consonant-skeleton similarity algorithms
 * 4. Deduplication and merging of multiple misspelled/variant names into single canonical identities
 */

import { Inspector } from '../types';

export const THAI_NAME_PREFIX_REGEX =
  /^(นาย|นางสาว|นาง|น\.ส\.|นส\.|ด\.ช\.|ด\.ญ\.|คุณ|ดร\.|อาจารย์|อ\.|ผศ\.|รศ\.|ศ\.|นพ\.|พญ\.|นายแพทย์|แพทย์หญิง|ส\.อ\.|ส\.ท\.|ส\.ต\.|จ\.ส\.อ\.|จ\.ส\.ท\.|จ\.ส\.ต\.|ร\.ต\.|ร\.ท\.|ร\.อ\.|พ\.ต\.|พ\.ท\.|พ\.อ\.|พ\.ต\.ต\.|พ\.ต\.ท\.|พ\.ต\.อ\.|ด\.ต\.|ส\.ต\.ต\.|ส\.ต\.ท\.|ส\.ต\.อ\.|ว่าที่\s*ร\.ต\.|ว่าที่ร้อยตรี|Mr\.|Mrs\.|Miss|Ms\.|Dr\.)\s*/i;

export interface CanonicalRosterPerson {
  id: string;
  fullNameWithTitle: string; // "นายชญานนท์ เชื้อคำ"
  cleanFullName: string;     // "ชญานนท์ เชื้อคำ"
  firstName: string;         // "ชญานนท์"
  lastName: string;          // "เชื้อคำ"
  position: string;
  department: string;
  variants: string[];        // Common typos / sub-strings
}

/**
 * Master Reference Roster of Verified Canonical Thai Personnel Names
 */
export const CANONICAL_PLANT_ROSTER: CanonicalRosterPerson[] = [
  {
    id: 'insp-1',
    fullNameWithTitle: 'นางพรพรรณ บุญจึงมงคล',
    cleanFullName: 'พรพรรณ บุญจึงมงคล',
    firstName: 'พรพรรณ',
    lastName: 'บุญจึงมงคล',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['พรพรรณ', 'พรพรรณ บุญจึงมงคล', 'บุญจึงมงคล'],
  },
  {
    id: 'insp-2',
    fullNameWithTitle: 'นายชิตทัตต์ นุ่มนิ่ม',
    cleanFullName: 'ชิตทัตต์ นุ่มนิ่ม',
    firstName: 'ชิตทัตต์',
    lastName: 'นุ่มนิ่ม',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['ชิตทัตต์', 'ชิตทัต', 'ชิตทัตต์ นุ่มนิ่ม', 'นุ่มนิ่ม'],
  },
  {
    id: 'insp-3',
    fullNameWithTitle: 'นายอานนท์ ภวรัญพงษ์',
    cleanFullName: 'อานนท์ ภวรัญพงษ์',
    firstName: 'อานนท์',
    lastName: 'ภวรัญพงษ์',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['อานนท์', 'อานน', 'อานนท', 'อานนท์ ภวรัญพงษ์', 'ภวรัญพงษ์', 'ภวรัญพงษ'],
  },
  {
    id: 'insp-4',
    fullNameWithTitle: 'นายสุรินทร์ สารอินทร์',
    cleanFullName: 'สุรินทร์ สารอินทร์',
    firstName: 'สุรินทร์',
    lastName: 'สารอินทร์',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['สุรินทร์', 'สุรินทร', 'สารอินทร์', 'สารอนินทร์', 'สุรินทร์ สารอินทร์', 'สุรินทร์ สารอนินทร์'],
  },
  {
    id: 'insp-5',
    fullNameWithTitle: 'ส.ท.ทรงศักดิ์ หุ้นศรี',
    cleanFullName: 'ทรงศักดิ์ หุ้นศรี',
    firstName: 'ทรงศักดิ์',
    lastName: 'หุ้นศรี',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['ทรงศักดิ์', 'ทรงศักดิ', 'หุ้นศรี', 'ทรงศักดิ์ หุ้นศรี', 'ส.ท.ทรงศักดิ์'],
  },
  {
    id: 'insp-6',
    fullNameWithTitle: 'ส.อ.กรกฎ แลบัว',
    cleanFullName: 'กรกฎ แลบัว',
    firstName: 'กรกฎ',
    lastName: 'แลบัว',
    position: 'ช่างชำนาญการ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['กรกฎ', 'กรกฏ', 'แลบัว', 'กรกฎ แลบัว', 'ส.อ.กรกฎ'],
  },
  {
    id: 'insp-7',
    fullNameWithTitle: 'นายกิติคุณ ลิ่วศิริวงษ์เจริญ',
    cleanFullName: 'กิติคุณ ลิ่วศิริวงษ์เจริญ',
    firstName: 'กิติคุณ',
    lastName: 'ลิ่วศิริวงษ์เจริญ',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: [
      'กิติคุณ',
      'กิตติคุณ',
      'กิติคูณ',
      'ลิ่วศิริวงษ์เจริญ',
      'ลิ่วศิริวงศ์เจริญ',
      'กิติคุณ ลิ่วศิริวงษ์เจริญ',
      'กิติคุณ ลิ่วศิริวงศ์เจริญ',
      'กิตติคุณ ลิ่วศิริวงศ์เจริญ',
      'กิตติคุณ ลิ่วศิริวงษ์เจริญ',
      'นายกิตติคุณ ลิ่วศิริวงศ์เจริญ',
      'นายกิตติคุณ ลิ่วศิริวงษ์เจริญ',
      'นายกิติคุณ ลิ่วศิริวงศ์เจริญ',
      'นายกิติคุณ ลิ่วศิริวงษ์เจริญ',
    ],
  },
  {
    id: 'insp-8',
    fullNameWithTitle: 'นายภานุพงศ์ ยามะสัก',
    cleanFullName: 'ภานุพงศ์ ยามะสัก',
    firstName: 'ภานุพงศ์',
    lastName: 'ยามะสัก',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['ภานุพงศ์', 'ภาณุพงศ์', 'ภานุพงษ์', 'ยามะสัก', 'ยามะสกุล', 'ภานุพงศ์ ยามะสัก', 'ภานุพงศ์ ยามะสกุล'],
  },
  {
    id: 'insp-9',
    fullNameWithTitle: 'นายนันทวัฒน์ พลเมฆ',
    cleanFullName: 'นันทวัฒน์ พลเมฆ',
    firstName: 'นันทวัฒน์',
    lastName: 'พลเมฆ',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['นันทวัฒน์', 'นันทวัฒน', 'พลเมฆ', 'นันทวัฒน์ พลเมฆ'],
  },
  {
    id: 'insp-10',
    fullNameWithTitle: 'นายชญานนท์ เชื้อคำ',
    cleanFullName: 'ชญานนท์ เชื้อคำ',
    firstName: 'ชญานนท์',
    lastName: 'เชื้อคำ',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['ชญานนท์', 'ชญานน', 'เชื้อคำ', 'นายชญานนท์ เชื้อคำ'],
  },
  {
    id: 'insp-11',
    fullNameWithTitle: 'นายพชรพล กลัดอินทร์',
    cleanFullName: 'พชรพล กลัดอินทร์',
    firstName: 'พชรพล',
    lastName: 'กลัดอินทร์',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['พชรพล', 'กลัดอินทร์', 'พชรพล กลัดอินทร์'],
  },
  {
    id: 'insp-12',
    fullNameWithTitle: 'นายพงษ์ศักดิ์ แสนอินต๊ะ',
    cleanFullName: 'พงษ์ศักดิ์ แสนอินต๊ะ',
    firstName: 'พงษ์ศักดิ์',
    lastName: 'แสนอินต๊ะ',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['พงษ์ศักดิ์', 'พงษ์ศักดิ', 'แสนอินต๊ะ', 'พงษ์ศักดิ์ แสนอินต๊ะ'],
  },
  {
    id: 'insp-13',
    fullNameWithTitle: 'นายณัฐวุฒิ เขียวใจยา',
    cleanFullName: 'ณัฐวุฒิ เขียวใจยา',
    firstName: 'ณัฐวุฒิ',
    lastName: 'เขียวใจยา',
    position: 'พนักงานตรวจสอบอุปกรณ์ / ผู้ตรวจสอบ',
    department: 'โรงไฟฟ้าจะนะ',
    variants: ['ณัฐวุฒิ', 'เขียวใจยา', 'ณัฐวุฒิ เขียวใจยา'],
  },
];

/**
 * Fast O(1) In-Memory Lookup Table & Memoization Caches
 */
const CANONICAL_MAP = new Map<string, string>();
const CANONICAL_CACHE = new Map<string, string>();
const SIMILARITY_CACHE = new Map<string, number>();

// Initialize quick hash index from CANONICAL_PLANT_ROSTER
for (const person of CANONICAL_PLANT_ROSTER) {
  CANONICAL_MAP.set(person.cleanFullName, person.fullNameWithTitle);
  CANONICAL_MAP.set(person.firstName, person.fullNameWithTitle);
  CANONICAL_MAP.set(stripThaiTitlePrefix(person.fullNameWithTitle), person.fullNameWithTitle);
  CANONICAL_MAP.set(person.fullNameWithTitle, person.fullNameWithTitle);

  for (const v of person.variants) {
    CANONICAL_MAP.set(v, person.fullNameWithTitle);
    CANONICAL_MAP.set(stripThaiTitlePrefix(v), person.fullNameWithTitle);
  }
}

/**
 * Strips title prefixes (นาย, นางสาว, ส.อ., etc.) and returns clean Thai name
 */
export function stripThaiTitlePrefix(fullName: string): string {
  if (!fullName) return '';
  let clean = fullName
    .normalize('NFC')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .trim();

  while (THAI_NAME_PREFIX_REGEX.test(clean)) {
    clean = clean.replace(THAI_NAME_PREFIX_REGEX, '').trim();
  }
  return clean.replace(/\s+/g, ' ');
}

/**
 * Applies general Thai grammatical rules to correct misspelled words in names:
 * 1. Missing Thanthakhat/Garan (ไม้ทัณฑฆาต ์) on silent trailing consonants
 * 2. Incomplete vowels like hanging mai-han-akat without final consonant (เช่น "สกั" -> "สกุล")
 * 3. Common consonant confusions (เช่น "กรกฏ" -> "กรกฎ")
 */
export function fixThaiNameGrammar(name: string): string {
  if (!name || typeof name !== 'string') return '';

  let s = name
    .normalize('NFC')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .trim()
    .replace(/\s+/g, ' ');

  // Quick check: if no Thai characters, return as is
  if (!/[\u0E00-\u0E7F]/.test(s)) return s;

  // 1. Incomplete/truncated word endings:
  // "สกั" at the end of word -> "สกุล" (as in "ยามะสกั" -> "ยามะสกุล")
  s = s.replace(/สกั(\s|$)/g, 'สกุล$1');

  // 2. Missing karun on common Thai name endings:
  // "นน" / "นนท" at end of name token -> "นนท์" (ชญานนท์, อานนท์, ชานนท์)
  s = s.replace(/([ก-ฮ])นน(\s|$)/g, '$1นนท์$2');
  s = s.replace(/([ก-ฮ])นนท(\s|$)/g, '$1นนท์$2');

  // "ศักดิ" / "ศักด" at end of token -> "ศักดิ์" (สมศักดิ์, ทรงศักดิ์, เกียรติศักดิ์)
  s = s.replace(/ศักดิ(\s|$)/g, 'ศักดิ์$1');
  s = s.replace(/ศักด(\s|$)/g, 'ศักดิ์$1');

  // "รินทร" / "รินท" -> "รินทร์" (สุรินทร์, สารอนินทร์, นรินทร์)
  s = s.replace(/รินทร(\s|$)/g, 'รินทร์$1');
  s = s.replace(/รินท(\s|$)/g, 'รินทร์$1');

  // "วัฒน" at end of token -> "วัฒน์" (นันทวัฒน์, ชัยวัฒน์)
  s = s.replace(/วัฒน(\s|$)/g, 'วัฒน์$1');

  // "พงศ" / "พงษ" at end of token -> "พงศ์" / "พงษ์"
  s = s.replace(/ภานุพงศ(\s|$)/g, 'ภานุพงศ์$1');
  s = s.replace(/ภาณุพงศ(\s|$)/g, 'ภานุพงศ์$1');
  s = s.replace(/ภานุพงษ์(\s|$)/g, 'ภานุพงศ์$1');
  s = s.replace(/ภานุพงษ(\s|$)/g, 'ภานุพงศ์$1');
  s = s.replace(/ภวรัญพงษ(\s|$)/g, 'ภวรัญพงษ์$1');

  // "สิทธิ" / "สิทธ" -> "สิทธิ์"
  s = s.replace(/สิทธิ(\s|$)/g, 'สิทธิ์$1');
  s = s.replace(/สิทธ(\s|$)/g, 'สิทธิ์$1');

  // "กรกฏ" -> "กรกฎ" (ชฎา)
  s = s.replace(/กรกฏ(\s|$)/g, 'กรกฎ$1');

  // "นภพร" -> "นพพร"
  s = s.replace(/นภพร(\s|$)/g, 'นพพร$1');

  // "กิตติคุณ" / "กิตติคูณ" -> "กิติคุณ"
  s = s.replace(/กิตติคุณ/g, 'กิติคุณ');
  s = s.replace(/กิตติคูณ(\s|$)/g, 'กิติคุณ$1');

  // "ลิ่วศิริวงศ์เจริญ" / "ลิ่วศิริวงค์เจริญ" / "ลิ่วศิริวงเจริญ" -> "ลิ่วศิริวงษ์เจริญ"
  s = s.replace(/ลิ่วศิริวง[ค์|ค|ษ]?์?เจริญ(\s|$)/g, 'ลิ่วศิริวงษ์เจริญ$1');
  s = s.replace(/ลิ่วศิริวงศ์เจริญ/g, 'ลิ่วศิริวงษ์เจริญ');

  // "พนเมฆ" -> "พลเมฆ"
  s = s.replace(/พนเมฆ(\s|$)/g, 'พลเมฆ$1');

  // "วิริยกิต" / "วิริยกิตติ์" -> "วิริยะกิจ"
  s = s.replace(/วิริยกิต[ติ์]?(\s|$)/g, 'วิริยะกิจ$1');

  // "เชื้อคำ่" -> "เชื้อคำ"
  s = s.replace(/เชื้อคำ[่้]?(\s|$)/g, 'เชื้อคำ$1');

  return s;
}

/**
 * Extracts consonants only from a Thai string (ignoring vowels, tone marks, punctuation)
 * Used for deep structural/phonetic comparison.
 */
export function extractThaiConsonants(str: string): string {
  return str.replace(/[^ก-ฮ]/g, '');
}

/**
 * High-performance 1D array Levenshtein edit distance with early exit
 */
export function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  if (Math.abs(m - n) > 4) return 10;

  const prev = new Int32Array(n + 1);
  const curr = new Int32Array(n + 1);

  for (let j = 0; j <= n; j++) prev[j] = j;

  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    const aChar = a.charCodeAt(i - 1);
    for (let j = 1; j <= n; j++) {
      const cost = aChar === b.charCodeAt(j - 1) ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= n; j++) {
      prev[j] = curr[j];
    }
  }
  return prev[n];
}

/**
 * Calculates similarity between two Thai name strings (range 0.0 to 1.0)
 * Uses composite metric with memoization cache
 */
export function calculateThaiNameSimilarity(a: string, b: string): number {
  if (!a || !b) return 0;
  if (a === b) return 1.0;

  const cacheKey = a < b ? `${a}:::${b}` : `${b}:::${a}`;
  const cached = SIMILARITY_CACHE.get(cacheKey);
  if (cached !== undefined) return cached;

  const normA = stripThaiTitlePrefix(fixThaiNameGrammar(a));
  const normB = stripThaiTitlePrefix(fixThaiNameGrammar(b));

  if (!normA || !normB) {
    SIMILARITY_CACHE.set(cacheKey, 0);
    return 0;
  }
  if (normA === normB) {
    SIMILARITY_CACHE.set(cacheKey, 1.0);
    return 1.0;
  }

  // Extract first names
  const tokenA = normA.split(/\s+/)[0] || '';
  const tokenB = normB.split(/\s+/)[0] || '';

  // First consonant check: Thai first names must share the same initial consonant
  const consA = extractThaiConsonants(tokenA);
  const consB = extractThaiConsonants(tokenB);

  if (consA.length === 0 || consB.length === 0 || consA.charAt(0) !== consB.charAt(0)) {
    SIMILARITY_CACHE.set(cacheKey, 0);
    return 0;
  }

  // Exact first name match (e.g. "ชญานนท์" vs "ชญานนท์ เชื้อคำ")
  if (tokenA === tokenB) {
    SIMILARITY_CACHE.set(cacheKey, 0.95);
    return 0.95;
  }

  // Token prefix match (e.g. "ชญานน" vs "ชญานนท์")
  if (tokenA.startsWith(tokenB) || tokenB.startsWith(tokenA)) {
    const minLen = Math.min(tokenA.length, tokenB.length);
    if (minLen >= 4) {
      SIMILARITY_CACHE.set(cacheKey, 0.92);
      return 0.92;
    }
  }

  // Consonant skeleton match
  const consDist = levenshtein(consA, consB);
  const maxConsLen = Math.max(consA.length, consB.length);
  const consSim = 1 - consDist / maxConsLen;

  // String edit distance on first name token
  const strDist = levenshtein(tokenA, tokenB);
  const maxStrLen = Math.max(tokenA.length, tokenB.length);
  const strSim = 1 - strDist / maxStrLen;

  const score = consSim * 0.6 + strSim * 0.4;
  SIMILARITY_CACHE.set(cacheKey, score);
  return score;
}

/**
 * Resolves any raw Thai inspector string to its verified canonical full name with O(1) caching
 */
export function getCanonicalThaiName(
  rawName: string,
  customInspectors: Inspector[] = []
): string {
  if (!rawName || typeof rawName !== 'string') return '';

  // 1. Cache hit check
  const cached = CANONICAL_CACHE.get(rawName);
  if (cached !== undefined) return cached;

  const cleanInput = stripThaiTitlePrefix(fixThaiNameGrammar(rawName));
  if (!cleanInput) {
    CANONICAL_CACHE.set(rawName, '');
    return '';
  }

  // 2. Direct O(1) Hash Map check against canonical dictionary
  const quick = CANONICAL_MAP.get(cleanInput) || CANONICAL_MAP.get(rawName.trim());
  if (quick) {
    CANONICAL_CACHE.set(rawName, quick);
    return quick;
  }

  // 3. Search against customInspectors
  for (const insp of customInspectors) {
    const cleanInsp = stripThaiTitlePrefix(fixThaiNameGrammar(insp.name));
    if (cleanInput === cleanInsp) {
      CANONICAL_CACHE.set(rawName, insp.name);
      return insp.name;
    }
    const sim = calculateThaiNameSimilarity(cleanInput, cleanInsp);
    if (sim >= 0.88) {
      CANONICAL_CACHE.set(rawName, insp.name);
      return insp.name;
    }
  }

  // 4. Fuzzy similarity match against plant roster
  for (const person of CANONICAL_PLANT_ROSTER) {
    const sim = calculateThaiNameSimilarity(cleanInput, person.cleanFullName);
    if (sim >= 0.88) {
      CANONICAL_CACHE.set(rawName, person.fullNameWithTitle);
      return person.fullNameWithTitle;
    }
  }

  // 5. Fallback: Return grammatically corrected version
  const fallback = fixThaiNameGrammar(rawName.trim());
  CANONICAL_CACHE.set(rawName, fallback);
  return fallback;
}

/**
 * Deduplicates and merges an array of Inspector objects into a single clean list:
 * - Detects duplicate inspectors caused by typos (e.g. "ชญานน", "ชญานนท์", "นายชญานนท์ เชื้อคำ")
 * - Unifies them into ONE single canonical Inspector
 * - Preserves the best available signature data URLs
 * - Merges without duplicates
 */
export function mergeAndDeduplicateInspectors(inspectors: Inspector[]): Inspector[] {
  const mergedMap = new Map<string, Inspector>();

  for (const insp of inspectors) {
    if (!insp || !insp.name) continue;

    const canonicalName = getCanonicalThaiName(insp.name, inspectors);
    const key = stripThaiTitlePrefix(canonicalName).toLowerCase();

    const existing = mergedMap.get(key);
    const rawAlias = insp.name.trim();

    if (!existing) {
      const initialAliases = new Set<string>(insp.aliases || []);
      if (rawAlias && rawAlias !== canonicalName) {
        initialAliases.add(rawAlias);
      }
      mergedMap.set(key, {
        ...insp,
        name: canonicalName,
        aliases: Array.from(initialAliases),
      });
    } else {
      // Merge: prefer inspector with signatures or complete full name
      const hasBetterSig =
        (!existing.signatureDataUrl && Boolean(insp.signatureDataUrl)) ||
        (!existing.verticalSignatureDataUrl && Boolean(insp.verticalSignatureDataUrl));

      const isLongerOfficialName = insp.name.length > existing.name.length;
      const mergedAliases = new Set<string>([
        ...(existing.aliases || []),
        ...(insp.aliases || []),
      ]);
      if (rawAlias && rawAlias !== canonicalName) {
        mergedAliases.add(rawAlias);
      }
      if (existing.name && existing.name !== canonicalName) {
        mergedAliases.add(existing.name);
      }

      mergedMap.set(key, {
        ...existing,
        name: isLongerOfficialName ? canonicalName : existing.name,
        signatureDataUrl: existing.signatureDataUrl || insp.signatureDataUrl,
        verticalSignatureDataUrl: existing.verticalSignatureDataUrl || insp.verticalSignatureDataUrl,
        position: existing.position || insp.position,
        department: existing.department || insp.department,
        aliases: Array.from(mergedAliases),
      });
    }
  }

  return Array.from(mergedMap.values()).sort((a, b) => a.name.localeCompare(b.name, 'th'));
}

export interface NameMergeAuditItem {
  raw: string;
  canonical: string;
  count: number;
  reason: string;
}

/**
 * Clusters all records, fixes grammatical typos in inspector names,
 * updates each record to reference the single unified canonical name,
 * and deduplicates the inspectors roster.
 */
export function clusterAndNormalizeRecords(
  records: any[],
  inspectors: Inspector[] = []
): {
  normalizedRecords: any[];
  deduplicatedInspectors: Inspector[];
  auditLogs: NameMergeAuditItem[];
} {
  // ดึงชื่อผู้ใช้งานจากไฟล์โดยตรง 100% ไม่ดัดแปลง ไม่แก้ไขคำผิด เพื่อให้คงตามไฟล์ต้นทาง
  const normalizedRecords = (records || []).map((rec) => {
    return {
      ...rec,
      inspectorName: (rec.inspectorName || '').trim(),
    };
  });

  return {
    normalizedRecords,
    deduplicatedInspectors: inspectors,
    auditLogs: [],
  };
}

/**
 * Filter inspectors by user query with character-similarity and fuzzy matching
 */
export function fuzzyFilterInspectors(inspectors: Inspector[], query: string): Inspector[] {
  if (!query || !query.trim()) return inspectors;

  const q = query.trim().toLowerCase();
  const qClean = stripThaiTitlePrefix(fixThaiNameGrammar(q)).toLowerCase();

  return inspectors.filter((insp) => {
    const name = insp.name.toLowerCase();
    const cleanName = stripThaiTitlePrefix(fixThaiNameGrammar(name)).toLowerCase();

    // 1. Direct contains
    if (name.includes(q) || cleanName.includes(qClean)) return true;

    // 2. Check aliases
    if (insp.aliases && insp.aliases.some((a) => a.toLowerCase().includes(q))) {
      return true;
    }

    // 3. Department or Position
    if (
      (insp.position && insp.position.toLowerCase().includes(q)) ||
      (insp.department && insp.department.toLowerCase().includes(q))
    ) {
      return true;
    }

    // 4. Similarity matching
    const sim = calculateThaiNameSimilarity(q, insp.name);
    return sim >= 0.75;
  });
}

